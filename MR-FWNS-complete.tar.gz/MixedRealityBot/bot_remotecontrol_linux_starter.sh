#!/bin/bash
eval "$*"
